/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package IBUrestaurant;

/**
 *
 * @author Arber Biljali
 */
public class Main {
   
    
    private static boolean authenticate(String username, String password){
        boolean result = false;
        
        if(username.equals("admin") && password.equals("admin")){
            result = true;
        } else {
            result = false;
        }
        
        
        return result;
    }
}
