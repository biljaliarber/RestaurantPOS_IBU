/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package IBUrestaurant;

import java.util.ArrayList;

import java.util.UUID;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


/**
 *
 * @author PC
 */
public class Order {
    
    private String orderId;
    private static ArrayList<Product> products = new ArrayList<Product>();
    
    public Order(String orderId){
        this.orderId = orderId;
    }
    
    public Order(){
        this.orderId = UUID.randomUUID().toString();
    }
    
    public void addProduct(Product product) {
        products.add(product);
    }
    
    
    public JSONObject orderToJson(){
        JSONArray ordersJson;
        JSONObject orderJson = new JSONObject();
        JSONArray productsJson = new JSONArray();
        
        Iterator iterator = this.products.iterator();
        while(iterator.hasNext()){
            JSONObject productJson = new JSONObject();
            Product product = (Product) iterator.next();
            
            productJson.put("productName", product.getProductName());
            productJson.put("productPrice", product.getProductPrice());
            productJson.put("productQuantity", product.getProductQuantity());
            productJson.put("productTotal", product.getProductTotal());
            
            productsJson.add(productJson);
        }
        
        orderJson.put("orderId", this.orderId);
        orderJson.put("products", productsJson);
        
        return orderJson;
    }
    
    
    public JSONArray getAllOrders() throws FileNotFoundException, IOException, ParseException {
        final String filePath = "Orders.json";
        JSONArray ordersJson;
        
        FileReader reader = new FileReader(filePath);
        JSONParser jsonParser = new JSONParser();
        ordersJson = (JSONArray) jsonParser.parse(reader);
        
        return ordersJson;
    }
    
    
    public void writeOrder() throws IOException, FileNotFoundException, ParseException{
        final String filePath = "Orders.json";
        
        JSONArray ordersJson = getAllOrders();
        JSONObject orderJson = orderToJson();
        ordersJson.add(orderJson);
        
        try (FileWriter fileWriter = new FileWriter(filePath)) {
            ordersJson.writeJSONString(ordersJson, fileWriter); 
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
    public Order readOrder(JSONObject orderJson){
        String orderId = orderJson.get("orderId").toString(); 
        Order order = new Order(orderId);
        
        JSONArray productsJson = (JSONArray) orderJson.get("products");

        Iterator iterator = productsJson.iterator();
        while(iterator.hasNext()){
            JSONObject jsonProduct = (JSONObject) iterator.next();
            String productName = jsonProduct.get("productName").toString();
            double productPrice = (double) jsonProduct.get("productPrice");
            int productQuantity = (int) jsonProduct.get("productQuantity");
                    
            Product product = new Product(productName, productPrice, productQuantity);
            order.addProduct(product);
        }
        
        return order;
    }

}
