/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package IBUrestaurant;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

//import IBUrestaurant.Order;
//import IBUrestaurant.Product;


/**
 *
 * @author Arber Biljali
 */
public class JsonTester {
    
    private static final String filePath = "Orders.json";
    
    public static void main(String[] args) throws FileNotFoundException, ParseException, IOException {
        JSONObject orderJson = new JSONObject();
        JSONObject productsJson = new JSONObject();
        JSONArray ordersJson = new JSONArray();
        
        productsJson.put("productName", "Coca Cola");
        productsJson.put("productPrice", 32);
        productsJson.put("productQuantity", 12);
        productsJson.put("productTotal", 345);
        
        orderJson.put("orderId", 12345);
        orderJson.put("products", productsJson);
        
        
        JSONObject orderJson1 = new JSONObject();
        JSONObject productsJson1 = new JSONObject();
        
        
        productsJson1.put("productName", "Coca Cola");
        productsJson1.put("productPrice", 32);
        productsJson1.put("productQuantity", 12);
        productsJson1.put("productTotal", 345);
        
        orderJson1.put("id", 12345);
        orderJson1.put("products", productsJson);
        
        
        ordersJson.add(orderJson);
        ordersJson.add(orderJson1);
        
        try (FileWriter fileWriter = new FileWriter(filePath)) {
            ordersJson.writeJSONString(ordersJson, fileWriter); 
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        System.out.println(ordersJson);
        
        
        
        /*
        try (FileReader reader = new FileReader(filePath)) {
            JSONParser jsonParser = new JSONParser();
            JSONArray ordersJson = (JSONArray) jsonParser.parse(reader);
            
            for(int json=0; json<ordersJson.size(); json++){
                JSONObject orderJson = (JSONObject) ordersJson.get(json);
                String orderId = orderJson.get("orderId").toString(); 
                Order order = new Order(orderId);
                
                JSONArray productsJson2 = (JSONArray) orderJson.get("products");
                
                Iterator iterator = productsJson2.iterator();
                while(iterator.hasNext()){
                    JSONObject jsonProduct = (JSONObject) iterator.next();
                    String productName = jsonProduct.get("productName").toString();
                    double productPrice = (double) jsonProduct.get("productPrice");
                    int productQuantity = (int) jsonProduct.get("productQuantity");
                    
                    Product product = new Product(productName, productPrice, productQuantity);
                    order.addProduct(product);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }*/
    }
}
