/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package IBUrestaurant;

/**
 *
 * @author PC
 */
public class Product {
    
    private String productName;
    private double productPrice;
    private int productQuantity;
    private double productTotal;
    
    public Product(String productName, double productPrice) {
        this.productName = productName;
        this.productPrice = productPrice;
        this.productQuantity = 0;
        this.productTotal = 0;
    }
    
    public Product(String productName, double productPrice, int productQuantity) {
        this.productName = productName;
        this.productPrice = productPrice;
        this.productQuantity = 0;
        this.productTotal = productPrice * productQuantity;
    }
    
            
    public String getProductName(){
        return this.productName;
    }
    
    
    public double getProductPrice() {
        return this.productPrice;
    }
    
    public int getProductQuantity() {
        return this.productQuantity;
    }
    
    public double getProductTotal() {
        return this.productTotal;
    }
}
